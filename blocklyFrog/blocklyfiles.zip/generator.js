
Blockly.JavaScript.frogs_begin = function() {
  var branch = Blockly.JavaScript.statementToCode(this, 'CODE');
  var code = "[" + branch + "]";
  return code;
};


Blockly.JavaScript.frogs_hop = function() {
  var arg = Blockly.JavaScript.valueToCode(this, 'COUNT', Blockly.JavaScript.ORDER_UNARY_NEGATION) || '0';
  var code = "[ 'hop', " + arg + "], ";
  return code;
};
