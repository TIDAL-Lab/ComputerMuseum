

// ---------------------------------
//   BEGIN
// ---------------------------------
Blockly.Language.frogs_begin = {
  category: 'Frogs',
  helpUrl: 'http://www.example.com/',
  init: function() {
    this.setColour(200);
    this.appendDummyInput()
        .appendTitle("PROGRAM");
    this.appendStatementInput("CODE");
    this.setTooltip('');
  }
};

// ---------------------------------
//   HOP      
// ---------------------------------
Blockly.Language.frogs_hop = {
  category: 'Frogs',
  helpUrl: 'http://www.example.com/',
  init: function() {
    this.setColour(290);
    this.appendValueInput("COUNT")
        .setCheck(Number)
        .appendTitle("hop");
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip('');
  }
};

Blockly.Language.controls_repeat = {
  // Repeat n times.
  category: "Frogs",
  helpUrl: Blockly.LANG_CONTROLS_REPEAT_HELPURL,
  init: function() {
    this.setColour(120);
    this.appendDummyInput()
        .appendTitle(Blockly.LANG_CONTROLS_REPEAT_TITLE_REPEAT)
        .appendTitle(new Blockly.FieldTextInput('10',
            Blockly.FieldTextInput.nonnegativeIntegerValidator), 'TIMES')
        .appendTitle(Blockly.LANG_CONTROLS_REPEAT_TITLE_TIMES);
    this.appendStatementInput('DO')
        .appendTitle(Blockly.LANG_CONTROLS_REPEAT_INPUT_DO);
    this.setPreviousStatement(true);
    this.setNextStatement(true);
    this.setTooltip(Blockly.LANG_CONTROLS_REPEAT_TOOLTIP);
  }
};

